
Chess Pieces - v1 aaa
==============================

This dataset was exported via roboflow.ai on November 26, 2020 at 2:38 PM GMT

It includes 289 images.
Pieces are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


